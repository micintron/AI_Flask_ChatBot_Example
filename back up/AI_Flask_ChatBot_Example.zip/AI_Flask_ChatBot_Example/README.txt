Basic Flask AI Chat Bot Official site. 

here you will see examples of how to set up a simple AI Chat bot
you can run a simple flask site with this Tensorflow based chatbot set up
or build out the chat section as a full api this site also features an sql data base for user management.

To build the site set up a virtual env in python 3
Install the requirements file with pip

Run the run file in the virtual env

The Scripts folder also has a Jupiter notebook with the full NLP model laid out 

You can retain the model with a new intents json file from the UI as well 

The structure is built to show how easy it can be to slot in a AI model with flask 
And allow you to change this model for another one or include multiples just as easily 




